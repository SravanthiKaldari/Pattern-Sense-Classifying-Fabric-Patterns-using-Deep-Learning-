import { Flower2, GripVertical, Shapes, MoreHorizontal } from 'lucide-react';
import type { SVGProps } from 'react';

const PolkaDotsIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg {...props} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <circle cx="6" cy="6" r="2.5" />
    <circle cx="18" cy="6" r="2.5" />
    <circle cx="12" cy="12" r="2.5" />
    <circle cx="6" cy="18" r="2.5" />
    <circle cx="18" cy="18" r="2.5" />
  </svg>
);

export const PatternIcon = ({ patternType, ...props }: { patternType: string } & SVGProps<SVGSVGElement>) => {
  const normalizedPattern = patternType.toLowerCase();
  
  if (normalizedPattern.includes('stripe')) {
    return <GripVertical {...props} />;
  }
  if (normalizedPattern.includes('dot')) {
    return <PolkaDotsIcon {...props} />;
  }
  if (normalizedPattern.includes('floral')) {
    return <Flower2 {...props} />;
  }
  if (normalizedPattern.includes('geometric')) {
    return <Shapes {...props} />;
  }
  return <MoreHorizontal {...props} />;
};
