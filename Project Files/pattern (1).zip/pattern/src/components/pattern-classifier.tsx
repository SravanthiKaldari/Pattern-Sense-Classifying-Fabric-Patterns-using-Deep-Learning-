"use client";

import { useState, useRef, ChangeEvent } from 'react';
import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { classifyImage } from '@/app/actions';
import type { HistoryItem, ClassificationResult } from '@/lib/types';
import { UploadCloud, FileImage, Loader2, Wand2 } from 'lucide-react';
import { PatternIcon } from './pattern-icon';

interface PatternClassifierProps {
  onClassificationComplete: (item: HistoryItem) => void;
}

export const PatternClassifier = ({ onClassificationComplete }: PatternClassifierProps) => {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageData, setImageData] = useState<string | null>(null);
  const [result, setResult] = useState<ClassificationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 4 * 1024 * 1024) { // 4MB limit
        toast({
          variant: 'destructive',
          title: 'File Too Large',
          description: 'Please upload an image smaller than 4MB.',
        });
        return;
      }
      setResult(null);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
        setImageData(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleClassify = async () => {
    if (!imageData) return;
    setIsLoading(true);
    setResult(null);

    const response = await classifyImage({ photoDataUri: imageData });

    setIsLoading(false);
    if (response.success) {
      setResult(response.data);
      onClassificationComplete({
        id: new Date().toISOString(),
        image: imageData,
        ...response.data,
      });
    } else {
      toast({
        variant: 'destructive',
        title: 'Classification Failed',
        description: response.error,
      });
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };
  
  const confidenceValue = result ? Math.round(result.confidenceScore * 100) : 0;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline">Fabric Pattern Classifier</CardTitle>
        <CardDescription>Upload an image to identify the fabric pattern.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div 
          className="relative aspect-video w-full border-2 border-dashed border-muted-foreground/30 rounded-lg flex items-center justify-center bg-muted/20 hover:border-primary transition-colors cursor-pointer"
          onClick={handleUploadClick}
        >
          {imagePreview ? (
            <Image src={imagePreview} alt="Fabric preview" layout="fill" objectFit="contain" className="rounded-lg" />
          ) : (
            <div className="text-center text-muted-foreground p-8">
              <UploadCloud className="mx-auto h-12 w-12 mb-2" />
              <p className="font-semibold">Click to upload or drag & drop</p>
              <p className="text-sm">PNG, JPG, WEBP (Max 4MB)</p>
            </div>
          )}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
            accept="image/png, image/jpeg, image/webp"
          />
        </div>
        
        {result && (
            <Card className="bg-muted/30">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 font-headline text-2xl">
                        <Wand2 className="text-accent"/>
                        Classification Result
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex items-center justify-between text-lg">
                        <div className="flex items-center gap-3 font-medium">
                            <PatternIcon patternType={result.patternType} className="w-8 h-8 text-primary" />
                            <span className="capitalize">{result.patternType}</span>
                        </div>
                         <span className="font-mono text-xl font-bold text-foreground">{confidenceValue}%</span>
                    </div>
                    <div>
                        <Progress value={confidenceValue} className="h-3" />
                         <p className="text-sm text-muted-foreground mt-2 text-right">Confidence Score</p>
                    </div>
                </CardContent>
            </Card>
        )}
      </CardContent>
      <CardFooter>
        <Button onClick={handleClassify} disabled={!imagePreview || isLoading} className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Analyzing Pattern...
            </>
          ) : (
            <>
              <FileImage className="mr-2 h-4 w-4" />
              Classify Pattern
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
};
