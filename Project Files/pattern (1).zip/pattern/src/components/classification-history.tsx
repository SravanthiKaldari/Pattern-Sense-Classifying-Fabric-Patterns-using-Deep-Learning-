import type { HistoryItem } from '@/lib/types';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import Image from 'next/image';
import { PatternIcon } from './pattern-icon';
import { Button } from './ui/button';
import { Trash2 } from 'lucide-react';

interface ClassificationHistoryProps {
  history: HistoryItem[];
  onClearHistory: () => void;
}

export const ClassificationHistory = ({ history, onClearHistory }: ClassificationHistoryProps) => {
  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="font-headline">History</CardTitle>
        {history.length > 0 && (
           <Button variant="ghost" size="sm" onClick={onClearHistory} aria-label="Clear history">
            <Trash2 className="h-4 w-4 mr-2" />
            Clear
          </Button>
        )}
      </CardHeader>
      <CardContent className="flex-grow p-0">
        <ScrollArea className="h-[60vh] lg:h-[calc(80vh-10rem)]">
          <div className="p-6 pt-0">
          {history.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground pt-16">
              <div className="mb-4 rounded-full border border-dashed p-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-10 w-10"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 12h4"/><path d="M8 17h8"/><path d="M10 12a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z"/></svg>
              </div>
              <p className="font-semibold">No classifications yet</p>
              <p className="text-sm">Your past results will appear here.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {history.map((item) => (
                <div key={item.id} className="flex items-start space-x-4">
                  <Image
                    src={item.image}
                    alt="Fabric pattern"
                    width={64}
                    height={64}
                    className="rounded-md object-cover aspect-square"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                       <PatternIcon patternType={item.patternType} className="h-4 w-4 text-muted-foreground" />
                      <p className="text-sm font-medium capitalize">{item.patternType}</p>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Confidence: {(item.confidenceScore * 100).toFixed(0)}%
                    </p>
                  </div>
                  <Badge variant="secondary" className="font-mono text-xs">
                    #{item.id.slice(0, 4)}
                  </Badge>
                </div>
              ))}
            </div>
          )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};
