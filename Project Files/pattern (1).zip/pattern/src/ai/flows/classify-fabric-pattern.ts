// use server'

/**
 * @fileOverview AI agent that classifies fabric patterns from an image.
 *
 * - classifyFabricPattern - A function that classifies the fabric pattern in an image.
 * - ClassifyFabricPatternInput - The input type for the classifyFabricPattern function.
 * - ClassifyFabricPatternOutput - The return type for the classifyFabricPattern function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ClassifyFabricPatternInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "A photo of a fabric pattern, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type ClassifyFabricPatternInput = z.infer<typeof ClassifyFabricPatternInputSchema>;

const ClassifyFabricPatternOutputSchema = z.object({
  patternType: z
    .string()
    .describe('The identified pattern type (e.g., stripes, polka dots, floral, geometric).'),
  confidenceScore: z
    .number()
    .describe('The confidence score (0-1) of the classification.'),
});
export type ClassifyFabricPatternOutput = z.infer<typeof ClassifyFabricPatternOutputSchema>;

export async function classifyFabricPattern(
  input: ClassifyFabricPatternInput
): Promise<ClassifyFabricPatternOutput> {
  return classifyFabricPatternFlow(input);
}

const prompt = ai.definePrompt({
  name: 'classifyFabricPatternPrompt',
  input: {schema: ClassifyFabricPatternInputSchema},
  output: {schema: ClassifyFabricPatternOutputSchema},
  prompt: `You are an AI expert in fabric pattern recognition.
  Analyze the image and classify the fabric pattern into one of the following categories: stripes, polka dots, floral, geometric, or other. Provide a confidence score (0-1) indicating the certainty of the classification.
  Respond in JSON format.

  Image: {{media url=photoDataUri}}
  `,
});

const classifyFabricPatternFlow = ai.defineFlow(
  {
    name: 'classifyFabricPatternFlow',
    inputSchema: ClassifyFabricPatternInputSchema,
    outputSchema: ClassifyFabricPatternOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
