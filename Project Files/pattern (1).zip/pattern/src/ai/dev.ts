import { config } from 'dotenv';
config();

import '@/ai/flows/classify-fabric-pattern.ts';