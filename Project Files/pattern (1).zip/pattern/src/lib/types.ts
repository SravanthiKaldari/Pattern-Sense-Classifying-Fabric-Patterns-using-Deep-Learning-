export type ClassificationResult = {
  patternType: string;
  confidenceScore: number;
};

export type HistoryItem = ClassificationResult & {
  id: string;
  image: string; 
};
