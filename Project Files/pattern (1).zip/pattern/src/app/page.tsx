"use client";

import { useState } from 'react';
import { PatternClassifier } from '@/components/pattern-classifier';
import { ClassificationHistory } from '@/components/classification-history';
import type { HistoryItem } from '@/lib/types';
import { Scissors } from 'lucide-react';

export default function Home() {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [runId, setRunId] = useState(0);

  const handleClassificationComplete = (item: HistoryItem) => {
    setHistory(prev => [item, ...prev]);
  };
  
  const handleClearHistory = () => {
    setHistory([]);
    setRunId(prev => prev + 1);
  }

  return (
    <main className="container mx-auto p-4 md:p-8">
      <header className="text-center mb-8 md:mb-12">
        <div className="inline-flex items-center gap-3 mb-2">
            <Scissors className="h-8 w-8 text-primary" />
            <h1 className="text-4xl md:text-5xl font-bold font-headline tracking-tight text-foreground">
              PatternSenseAI
            </h1>
        </div>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto font-body">
          Upload a fabric image to automatically classify its pattern. Our AI analyzes stripes, dots, florals, and more with high accuracy.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        <div className="lg:col-span-2">
          <PatternClassifier 
            key={runId}
            onClassificationComplete={handleClassificationComplete} 
          />
        </div>
        <div className="lg:col-span-1">
          <ClassificationHistory history={history} onClearHistory={handleClearHistory} />
        </div>
      </div>
    </main>
  );
}
