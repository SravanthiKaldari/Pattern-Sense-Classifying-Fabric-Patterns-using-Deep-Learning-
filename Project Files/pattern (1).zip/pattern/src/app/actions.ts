'use server';

import { classifyFabricPattern, type ClassifyFabricPatternOutput } from '@/ai/flows/classify-fabric-pattern';
import { z } from 'zod';
import { Ratelimit } from "@upstash/ratelimit";
import { kv } from "@vercel/kv";
import { headers } from "next/headers";

const actionInputSchema = z.object({
  photoDataUri: z.string().refine(val => val.startsWith('data:image/'), {
    message: 'Invalid image data URI',
  }),
});

const ratelimit = new Ratelimit({
  redis: kv,
  limiter: Ratelimit.slidingWindow(5, "1 m"),
});

export async function classifyImage(
  data: { photoDataUri: string }
): Promise<{ success: true; data: ClassifyFabricPatternOutput } | { success: false; error: string }> {
  
  const ip = headers().get("x-forwarded-for");
  const { success: limitSuccess } = await ratelimit.limit(ip ?? "anonymous");

  if (!limitSuccess) {
    return { success: false, error: "Rate limit exceeded. Please try again in a minute." };
  }
  
  const validation = actionInputSchema.safeParse(data);
  if (!validation.success) {
    const error = validation.error.flatten().fieldErrors.photoDataUri?.[0] ?? 'Invalid input.';
    return { success: false, error };
  }

  try {
    const result = await classifyFabricPattern(validation.data);
    return { success: true, data: result };
  } catch (e) {
    console.error(e);
    return { success: false, error: 'Failed to classify the image. Please try again.' };
  }
}
