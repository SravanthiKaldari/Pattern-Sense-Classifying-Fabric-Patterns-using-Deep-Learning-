# **App Name**: PatternSenseAI

## Core Features:

- AI Pattern Classification: Use AI to automatically classify fabric patterns into predefined categories such as stripes, polka dots, floral, and geometric designs. Leverages a trained deep learning model to accurately identify patterns from uploaded images.
- Image Upload: Upload an image of a fabric pattern for analysis.
- Classification Result Display: Display the classification result, including the identified pattern type and a confidence score.
- History Tracking: Show a history of uploaded images and their corresponding classifications.

## Style Guidelines:

- Primary color: Soft blue (#A0D2EB) to evoke a sense of trust and precision, mirroring the accuracy of AI classification.
- Background color: Light gray (#F0F4F8) to provide a clean and neutral backdrop that highlights fabric patterns.
- Accent color: Muted orange (#E59866) for interactive elements and calls to action, adding warmth to the technical feel.
- Font pairing: 'Poppins' (sans-serif) for headings to convey a geometric, fashionable style; and 'PT Sans' (sans-serif) for body text, to provide clarity and readability.
- Use a clean, modern layout with clear sections for image upload, classification results, and history.
- Utilize minimalist icons to represent different fabric pattern categories, ensuring visual clarity.